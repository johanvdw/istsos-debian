version_info = (2, 1, 1)
version = '.'.join(str(n) for n in version_info[:3])
release = '.'.join(str(n) for n in version_info)
